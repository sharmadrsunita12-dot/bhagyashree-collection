"use client"

import { useState } from "react"
import Image from "next/image"
import { ArrowRight } from "lucide-react"

const categories = [
  {
    id: 1,
    name: "Sarees",
    count: "120+ Products",
    image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=600&h=800&fit=crop",
    description: "Elegant traditional sarees"
  },
  {
    id: 2,
    name: "Lehengas",
    count: "85+ Products",
    image: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=600&h=800&fit=crop",
    description: "Bridal & festive lehengas"
  },
  {
    id: 3,
    name: "Suits & Kurtis",
    count: "200+ Products",
    image: "https://images.unsplash.com/photo-1594463750939-ebb28c3f7f75?w=600&h=800&fit=crop",
    description: "Daily & party wear suits"
  },
]

export function Categories() {
  const [hoveredId, setHoveredId] = useState<number | null>(null)

  return (
    <section id="shop" className="py-24 bg-secondary/30">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <p className="text-sm tracking-[0.3em] text-primary uppercase mb-3">Shop by Category</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-foreground text-balance">
            Discover Our Collections
          </h2>
          <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
            From everyday elegance to bridal grandeur, find your perfect outfit
          </p>
        </div>

        {/* Categories grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {categories.map((category) => (
            <div
              key={category.id}
              className="group relative overflow-hidden rounded-2xl bg-card cursor-pointer"
              onMouseEnter={() => setHoveredId(category.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              {/* Image */}
              <div className="aspect-[3/4] relative overflow-hidden">
                <Image
                  src={category.image}
                  alt={category.name}
                  fill
                  className={`object-cover transition-transform duration-700 ${
                    hoveredId === category.id ? "scale-110" : "scale-100"
                  }`}
                />
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/20 to-transparent" />
              </div>

              {/* Content */}
              <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-8">
                <p className="text-xs tracking-wider text-primary-foreground/70 uppercase mb-1">
                  {category.count}
                </p>
                <h3 className="text-2xl lg:text-3xl font-serif font-bold text-primary-foreground mb-2">
                  {category.name}
                </h3>
                <p className="text-sm text-primary-foreground/80 mb-4">
                  {category.description}
                </p>
                <div className={`flex items-center gap-2 text-primary-foreground transition-all duration-300 ${
                  hoveredId === category.id ? "translate-x-2" : ""
                }`}>
                  <span className="text-sm font-medium">Explore</span>
                  <ArrowRight className="h-4 w-4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
