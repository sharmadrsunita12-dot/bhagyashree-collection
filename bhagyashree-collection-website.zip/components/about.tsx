import Image from "next/image"
import { Quote } from "lucide-react"

export function About() {
  return (
    <section id="about" className="py-24 bg-secondary/30">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image */}
          <div className="relative">
            <div className="aspect-[4/5] rounded-2xl overflow-hidden">
              <Image
                src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=600&h=750&fit=crop"
                alt="Our store interior"
                fill
                className="object-cover"
              />
            </div>
            {/* Decorative element */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-primary/10 rounded-full -z-10" />
            <div className="absolute -top-6 -left-6 w-24 h-24 bg-accent/10 rounded-full -z-10" />
          </div>

          {/* Content */}
          <div>
            <p className="text-sm tracking-[0.3em] text-primary uppercase mb-3">Our Story</p>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-foreground mb-6 text-balance">
              A Legacy of <span className="italic">Elegance</span>
            </h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Nestled in the heart of Sector 3, Udaipur, Bhagyashree Collection has been serving 
                discerning customers for over 15 years. Our journey began with a simple vision — 
                to bring the finest ethnic wear to the City of Lakes.
              </p>
              <p>
                From handpicked Bandhani sarees to intricately embroidered lehengas, every piece 
                in our collection tells a story of Rajasthani craftsmanship and timeless beauty. 
                We work directly with artisans across India to bring you authentic, high-quality 
                fashion at honest prices.
              </p>
            </div>

            {/* Quote */}
            <div className="mt-8 p-6 bg-card rounded-xl border border-border">
              <Quote className="h-8 w-8 text-primary/30 mb-3" />
              <p className="text-foreground italic font-serif text-lg">
                {`"Every woman deserves to feel like royalty. That's what we strive to deliver with every outfit."`}
              </p>
              <p className="mt-4 text-sm text-muted-foreground">— Bhagyashree Collection Family</p>
            </div>

            {/* Features */}
            <div className="mt-10 grid grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-foreground mb-1">Quality Assured</h4>
                <p className="text-sm text-muted-foreground">
                  Every piece is quality checked before reaching you
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-1">Fair Pricing</h4>
                <p className="text-sm text-muted-foreground">
                  Direct from artisans, no middlemen markups
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
