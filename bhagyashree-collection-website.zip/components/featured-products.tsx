"use client"

import Image from "next/image"
import { Heart, ShoppingBag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

const products = [
  {
    id: 1,
    name: "Bandhani Silk Saree",
    price: "₹4,999",
    originalPrice: "₹6,499",
    image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=400&h=500&fit=crop",
    badge: "Bestseller",
    isNew: false,
  },
  {
    id: 2,
    name: "Embroidered Lehenga Set",
    price: "₹12,999",
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=400&h=500&fit=crop",
    badge: null,
    isNew: true,
  },
  {
    id: 3,
    name: "Chanderi Cotton Kurti",
    price: "₹1,499",
    originalPrice: "₹1,999",
    image: "https://images.unsplash.com/photo-1594463750939-ebb28c3f7f75?w=400&h=500&fit=crop",
    badge: "Sale",
    isNew: false,
  },
  {
    id: 4,
    name: "Banarasi Brocade Saree",
    price: "₹8,499",
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1617627143233-46bf50ac3a88?w=400&h=500&fit=crop",
    badge: null,
    isNew: true,
  },
  {
    id: 5,
    name: "Anarkali Suit Set",
    price: "₹3,999",
    originalPrice: "₹5,499",
    image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=500&fit=crop",
    badge: "Sale",
    isNew: false,
  },
  {
    id: 6,
    name: "Rajasthani Gota Dupatta",
    price: "₹2,499",
    originalPrice: null,
    image: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=400&h=500&fit=crop",
    badge: null,
    isNew: false,
  },
]

export function FeaturedProducts() {
  return (
    <section id="collections" className="py-24 bg-background">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        {/* Section header */}
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between mb-12">
          <div>
            <p className="text-sm tracking-[0.3em] text-primary uppercase mb-3">Featured</p>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-foreground">
              New Arrivals
            </h2>
          </div>
          <Button variant="link" className="text-primary mt-4 sm:mt-0 p-0">
            View All Products →
          </Button>
        </div>

        {/* Products grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 lg:gap-8">
          {products.map((product) => (
            <div key={product.id} className="group">
              {/* Image container */}
              <div className="relative aspect-[4/5] overflow-hidden rounded-xl bg-muted mb-4">
                <Image
                  src={product.image}
                  alt={product.name}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
                
                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-col gap-2">
                  {product.isNew && (
                    <Badge className="bg-foreground text-background text-xs px-2 py-1">
                      New
                    </Badge>
                  )}
                  {product.badge && (
                    <Badge variant="secondary" className="text-xs px-2 py-1">
                      {product.badge}
                    </Badge>
                  )}
                </div>

                {/* Hover actions */}
                <div className="absolute bottom-3 right-3 flex gap-2 opacity-0 translate-y-2 transition-all duration-300 group-hover:opacity-100 group-hover:translate-y-0">
                  <Button size="icon" variant="secondary" className="h-9 w-9 rounded-full shadow-lg" aria-label="Add to wishlist">
                    <Heart className="h-4 w-4" />
                  </Button>
                  <Button size="icon" className="h-9 w-9 rounded-full shadow-lg" aria-label="Add to cart">
                    <ShoppingBag className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Product info */}
              <div>
                <h3 className="font-medium text-foreground group-hover:text-primary transition-colors line-clamp-1">
                  {product.name}
                </h3>
                <div className="mt-1 flex items-center gap-2">
                  <span className="font-semibold text-foreground">{product.price}</span>
                  {product.originalPrice && (
                    <span className="text-sm text-muted-foreground line-through">
                      {product.originalPrice}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
