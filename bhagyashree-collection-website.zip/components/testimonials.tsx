import { Star } from "lucide-react"

const testimonials = [
  {
    id: 1,
    name: "Priya Sharma",
    location: "Udaipur",
    rating: 5,
    text: "Found my dream wedding lehenga here! The staff was incredibly helpful and the quality exceeded my expectations. Truly a gem in Udaipur.",
  },
  {
    id: 2,
    name: "Meena Agarwal",
    location: "Jaipur",
    rating: 5,
    text: "I visit Bhagyashree Collection every time I come to Udaipur. Their saree collection is unmatched. Authentic Bandhani at great prices!",
  },
  {
    id: 3,
    name: "Anjali Rathore",
    location: "Ahmedabad",
    rating: 5,
    text: "The ethnic wear collection here is stunning. I bought suits for my entire family. Everyone loved the quality and designs!",
  },
]

export function Testimonials() {
  return (
    <section className="py-24 bg-background">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <p className="text-sm tracking-[0.3em] text-primary uppercase mb-3">Testimonials</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-foreground text-balance">
            What Our Customers Say
          </h2>
        </div>

        {/* Testimonials grid */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {testimonials.map((testimonial) => (
            <div 
              key={testimonial.id} 
              className="bg-card p-6 lg:p-8 rounded-2xl border border-border hover:shadow-lg transition-shadow"
            >
              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-accent text-accent" />
                ))}
              </div>
              
              {/* Quote */}
              <p className="text-foreground leading-relaxed mb-6">
                {`"${testimonial.text}"`}
              </p>
              
              {/* Author */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-sm font-semibold text-primary">
                    {testimonial.name.charAt(0)}
                  </span>
                </div>
                <div>
                  <p className="font-medium text-foreground">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
