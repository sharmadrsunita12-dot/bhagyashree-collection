import Link from "next/link"
import { Instagram, Facebook, Mail, Phone } from "lucide-react"

const footerLinks = {
  shop: [
    { name: "Sarees", href: "#" },
    { name: "Lehengas", href: "#" },
    { name: "Suits & Kurtis", href: "#" },
    { name: "Dupattas", href: "#" },
    { name: "New Arrivals", href: "#" },
  ],
  support: [
    { name: "Contact Us", href: "#contact" },
    { name: "Size Guide", href: "#" },
    { name: "Shipping Info", href: "#" },
    { name: "Returns", href: "#" },
    { name: "FAQs", href: "#" },
  ],
  company: [
    { name: "About Us", href: "#about" },
    { name: "Our Story", href: "#" },
    { name: "Store Location", href: "#contact" },
    { name: "Careers", href: "#" },
  ],
}

export function Footer() {
  return (
    <footer className="bg-foreground text-background">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Brand */}
          <div className="col-span-2 lg:col-span-2">
            <Link href="/" className="inline-block">
              <span className="text-2xl font-serif font-bold tracking-tight text-background">
                Bhagyashree
              </span>
              <span className="block text-xs tracking-[0.3em] text-background/60 uppercase">
                Collection
              </span>
            </Link>
            <p className="mt-4 text-background/70 text-sm leading-relaxed max-w-xs">
              Your destination for premium ethnic wear in Udaipur. 
              Traditional craftsmanship meets contemporary elegance.
            </p>
            
            {/* Contact info */}
            <div className="mt-6 space-y-2">
              <div className="flex items-center gap-2 text-sm text-background/70">
                <Phone className="h-4 w-4" />
                <span>+91 98765 43210</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-background/70">
                <Mail className="h-4 w-4" />
                <span>info@bhagyashreecollection.com</span>
              </div>
            </div>

            {/* Social */}
            <div className="mt-6 flex gap-4">
              <Link 
                href="#" 
                className="text-background/60 hover:text-background transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </Link>
              <Link 
                href="#" 
                className="text-background/60 hover:text-background transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </Link>
            </div>
          </div>

          {/* Shop links */}
          <div>
            <h3 className="text-sm font-semibold text-background mb-4">Shop</h3>
            <ul className="space-y-3">
              {footerLinks.shop.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href}
                    className="text-sm text-background/60 hover:text-background transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support links */}
          <div>
            <h3 className="text-sm font-semibold text-background mb-4">Support</h3>
            <ul className="space-y-3">
              {footerLinks.support.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href}
                    className="text-sm text-background/60 hover:text-background transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company links */}
          <div>
            <h3 className="text-sm font-semibold text-background mb-4">Company</h3>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href}
                    className="text-sm text-background/60 hover:text-background transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-16 pt-8 border-t border-background/10">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-xs text-background/50">
              © {new Date().getFullYear()} Bhagyashree Collection. All rights reserved.
            </p>
            <p className="text-xs text-background/50">
              Sector 3, Hiran Magri, Udaipur, Rajasthan, India
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
