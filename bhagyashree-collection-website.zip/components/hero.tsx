"use client"

import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20">
      {/* Background pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-secondary via-background to-background" />
      
      <div className="relative mx-auto max-w-7xl px-6 py-24 lg:px-8">
        <div className="text-center">
          {/* Tagline */}
          <p className="text-sm tracking-[0.4em] text-muted-foreground uppercase mb-6">
            Since Generations • Udaipur, Rajasthan
          </p>
          
          {/* Main heading */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif font-bold tracking-tight text-foreground leading-tight text-balance">
            Timeless elegance
            <br />
            <span className="italic text-primary">meets tradition</span>
          </h1>
          
          {/* Description */}
          <p className="mt-8 text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed text-pretty">
            Discover our exquisite collection of ethnic wear, curated with love from 
            the heart of Rajasthan. Where royal heritage meets contemporary style.
          </p>
          
          {/* CTA buttons */}
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button size="lg" className="px-8 py-6 text-base font-medium group">
              Explore Collection
              <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Button>
            <Button variant="outline" size="lg" className="px-8 py-6 text-base font-medium">
              Visit Our Store
            </Button>
          </div>
          
          {/* Stats */}
          <div className="mt-20 grid grid-cols-3 gap-8 max-w-lg mx-auto">
            <div>
              <p className="text-3xl sm:text-4xl font-serif font-bold text-foreground">15+</p>
              <p className="mt-1 text-sm text-muted-foreground">Years of Trust</p>
            </div>
            <div>
              <p className="text-3xl sm:text-4xl font-serif font-bold text-foreground">5000+</p>
              <p className="mt-1 text-sm text-muted-foreground">Happy Customers</p>
            </div>
            <div>
              <p className="text-3xl sm:text-4xl font-serif font-bold text-foreground">500+</p>
              <p className="mt-1 text-sm text-muted-foreground">Unique Designs</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative scroll indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        <span className="text-xs tracking-widest text-muted-foreground uppercase">Scroll</span>
        <div className="w-px h-12 bg-gradient-to-b from-primary/50 to-transparent" />
      </div>
    </section>
  )
}
